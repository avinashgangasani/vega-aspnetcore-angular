import { Contact } from "./Contact";
import { KeyValuePair } from "./KeyValuePair";

export interface Vehcile{
    Id: number,
    make: KeyValuePair,
    model: KeyValuePair,
    isRegistered: boolean,
    contact: Contact,
    lastUpdated: string,
    features: KeyValuePair[]
}