import { Component, OnInit } from '@angular/core';

// Import the AuthService type from the SDK
import { AuthService } from '@auth0/auth0-angular';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  user: any;
  constructor(private _auth: AuthService) { }

  ngOnInit(): void {
    this.getUserInfo();
  }

  getUserInfo()
  {    
    this._auth.user$.subscribe((user) => {
      this.user = user;
      console.log(user);
    })
  }

}
