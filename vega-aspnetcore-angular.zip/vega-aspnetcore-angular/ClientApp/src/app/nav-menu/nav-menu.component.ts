import { DOCUMENT } from '@angular/common';
import { Component, Inject } from '@angular/core';

// Import the AuthService type from the SDK
import { AuthService } from '@auth0/auth0-angular';

@Component({
  selector: 'app-nav-menu',
  templateUrl: './nav-menu.component.html',
  styleUrls: ['./nav-menu.component.css']
})
export class NavMenuComponent {
  isExpanded = false;
  isAuthenticated: boolean = false;

  // Inject the authentication service into your component through the constructor
  constructor(@Inject(DOCUMENT) public document: Document, private _auth: AuthService) {
    this.checkAuthentication();
  }

  login() {
    this._auth.loginWithRedirect();
    this.checkAuthentication();
  }

  logout() {
    this._auth.logout({ returnTo: document.location.origin });
    this.checkAuthentication();
  }

  collapse() {
    this.isExpanded = false;
  }

  toggle() {
    this.isExpanded = !this.isExpanded;
  }

  checkAuthentication(){
    console.log(this._auth.isAuthenticated$);
    this._auth.isAuthenticated$.subscribe((data) => {
      this.isAuthenticated = data;
    })
  }
}
