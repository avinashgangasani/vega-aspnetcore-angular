import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { HomeComponent } from './home/home.component';
import { CounterComponent } from './counter/counter.component';
import { FetchDataComponent } from './fetch-data/fetch-data.component';
import { VehilceFormComponent } from './vehilce-form/vehilce-form.component';
import { VehicleListComponent } from './vehicle-list/vehicle-list.component';
import { VehicleService } from './services/vehicle.service';

// Import the module from the SDK
import { AuthModule } from '@auth0/auth0-angular';
import { UserComponent } from './user/user.component';
// // Import the AuthService type from the SDK
// import { AuthService } from '@auth0/auth0-angular';

@NgModule({
  declarations: [
    AppComponent,
    NavMenuComponent,
    HomeComponent,
    CounterComponent,
    FetchDataComponent,
    VehilceFormComponent,
    VehicleListComponent,
    UserComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      { path: '', component: HomeComponent, pathMatch: 'full' },
      { path: 'counter', component: CounterComponent },
      { path: 'fetch-data', component: FetchDataComponent },
      { path: 'vehicles/new', component: VehilceFormComponent },
      { path: 'vehicles/new/:id', component: VehilceFormComponent },
      { path: 'vehicles/list', component: VehicleListComponent },
      { path: 'user', component: UserComponent },
    ]),
    // Import the module into the application, with configuration
    AuthModule.forRoot({
      domain: 'vegastore.us.auth0.com',
      clientId: 'lM0dKTRp9Dmz2CMDO8o61NqllJ1k60pH'
    }),
  ],
  providers: [VehicleService],//, AuthService
  bootstrap: [AppComponent]
})
export class AppModule { }
