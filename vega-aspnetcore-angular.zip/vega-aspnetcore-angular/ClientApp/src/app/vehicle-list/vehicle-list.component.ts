import { identifierModuleUrl } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { VehicleService} from 'src/app/services/vehicle.service';
import { Vehcile } from '../models/Vehicle';

@Component({
  selector: 'app-vehicle-list',
  templateUrl: './vehicle-list.component.html',
  styleUrls: ['./vehicle-list.component.css']
})
export class VehicleListComponent implements OnInit {
  vehicles: Vehcile[];
  makes: any;
  models: any[];
  filter: any = {
  }
  dataLoaded: boolean = false;

  constructor(private vehicleService: VehicleService) { }

  ngOnInit() {
    this.getAllVehicles();
    this.getMakes();
  }

  getMakes(){
    this.vehicleService.getMakes().subscribe((data) => {
      this.makes = data;
      console.log('makes', this.makes);
    });
  }

  onMakeChanged(){
    console.log("make changed");
    let makeModels = this.makes.find(x => x.id == parseInt(this.filter["makeId"]));

    if(makeModels)
    {
      this.models = makeModels.models;
    }    
  }

  onSearch(){
    this.getAllVehicles();
  }

  onReset()
  {
    this.filter = {};
    this.getAllVehicles();
  }

  getAllVehicles(){    
    this.vehicleService.getAllVehicles(this.filter).subscribe((data) => {
      this.vehicles = data as Vehcile[];
      this.dataLoaded = true;
    });
  }
}
