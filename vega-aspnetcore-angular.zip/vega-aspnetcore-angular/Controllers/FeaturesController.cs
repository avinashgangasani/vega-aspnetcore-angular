using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using vega_aspnetcore_angular.Controllers.Resources;
using vega_aspnetcore_angular.Core.Models;
using vega_aspnetcore_angular.Persistence;

namespace vega_aspnetcore_angular.Controllers
{
    public class FeaturesController: Controller
    {
        private readonly VegaDBContext context;
        private readonly IMapper mapper;

        public FeaturesController(VegaDBContext context, IMapper mapper)
        {
            this.mapper = mapper;
            this.context = context;
        }

        [HttpGet("/api/features")]
        async public Task<IEnumerable<KeyValuePairResource>> Get()
        {
            var features = await context.Features.ToListAsync();

            return mapper.Map<List<Feature>, List<KeyValuePairResource>>(features);            
        }
    }
}