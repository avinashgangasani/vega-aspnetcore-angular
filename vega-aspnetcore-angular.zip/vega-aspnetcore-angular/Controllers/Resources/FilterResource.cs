namespace vega_aspnetcore_angular.Controllers.Resources
{
    public class FilterResource
    {
        public int? MakeId { get; set; }
        public int? ModelId { get; set; }

    }
}