namespace vega_aspnetcore_angular.Controllers.Resources
{
    public class KeyValuePairResource
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}