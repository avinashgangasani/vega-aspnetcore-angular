using System.Collections.Generic;
using System.Threading.Tasks;
using vega_aspnetcore_angular.Core.Models;

namespace vega_aspnetcore_angular.Persistence
{
    public interface IVehicleRepository
    {
         Task<Vehicle> GetVehicleById(int Id, bool getRelatedData = true);
         void AddVehicle(Vehicle vehicle);
         void DeleteVehicle(Vehicle vehicle);
         Task<Model> GetVehicleModel(int Id);
         Task<IEnumerable<Vehicle>> GetAllVehicles(Filter filter);
    }
}