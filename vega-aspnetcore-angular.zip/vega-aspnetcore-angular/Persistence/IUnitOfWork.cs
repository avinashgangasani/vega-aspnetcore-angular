using System.Threading.Tasks;

namespace vega_aspnetcore_angular.Persistence
{
    public interface IUnitOfWork
    {
         Task CompletedAsync();
    }
}