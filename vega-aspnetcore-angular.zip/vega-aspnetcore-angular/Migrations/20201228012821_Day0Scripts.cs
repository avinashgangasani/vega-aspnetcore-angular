﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace vega_aspnetcore_angular.Migrations
{
    public partial class Day0Scripts : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("INSERT INTO MAKES(NAME) VALUES ('Make1')");
            migrationBuilder.Sql("INSERT INTO MAKES(NAME) VALUES ('Make2')");
            migrationBuilder.Sql("INSERT INTO MAKES(NAME) VALUES ('Make3')");

            migrationBuilder.Sql("INSERT INTO MODELS(NAME, MAKEID) VALUES ('Make1-ModelA', (SELECT ID FROM MAKES WHERE NAME='MAKE1'))");
            migrationBuilder.Sql("INSERT INTO MODELS(NAME, MAKEID) VALUES ('Make1-ModelB', (SELECT ID FROM MAKES WHERE NAME='MAKE1'))");
            migrationBuilder.Sql("INSERT INTO MODELS(NAME, MAKEID) VALUES ('Make1-ModelC', (SELECT ID FROM MAKES WHERE NAME='MAKE1'))");

            migrationBuilder.Sql("INSERT INTO MODELS(NAME, MAKEID) VALUES ('Make2-ModelA', (SELECT ID FROM MAKES WHERE NAME='MAKE2'))");
            migrationBuilder.Sql("INSERT INTO MODELS(NAME, MAKEID) VALUES ('Make2-ModelB', (SELECT ID FROM MAKES WHERE NAME='MAKE2'))");
            migrationBuilder.Sql("INSERT INTO MODELS(NAME, MAKEID) VALUES ('Make2-ModelC', (SELECT ID FROM MAKES WHERE NAME='MAKE2'))");

            migrationBuilder.Sql("INSERT INTO MODELS(NAME, MAKEID) VALUES ('Make3-ModelA', (SELECT ID FROM MAKES WHERE NAME='MAKE3'))");
            migrationBuilder.Sql("INSERT INTO MODELS(NAME, MAKEID) VALUES ('Make3-ModelB', (SELECT ID FROM MAKES WHERE NAME='MAKE3'))");
            migrationBuilder.Sql("INSERT INTO MODELS(NAME, MAKEID) VALUES ('Make3-ModelC', (SELECT ID FROM MAKES WHERE NAME='MAKE3'))");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("TRUNCATE TABLE MODELS");
            migrationBuilder.Sql("DELETE MAKES");
        }
    }
}
