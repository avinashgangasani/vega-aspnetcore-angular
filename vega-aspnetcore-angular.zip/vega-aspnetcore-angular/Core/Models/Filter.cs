namespace vega_aspnetcore_angular.Core.Models
{
    public class Filter
    {
        public int? MakeId { get; set; }
        public int? ModelId { get; set; }    
        
    }
}