using System.ComponentModel.DataAnnotations.Schema;
namespace vega_aspnetcore_angular.Core.Models
{
    [Table("Features")]
    public class Feature
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}