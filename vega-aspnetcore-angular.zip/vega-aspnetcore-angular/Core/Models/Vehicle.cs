using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

namespace vega_aspnetcore_angular.Core.Models
{
    [Table("Vehicles")]
    public class Vehicle
    {
        public int Id { get; set; }

        public int ModelId { get; set; }       
        
        
        public Model Model { get; set; }
        
        public bool IsRegistered { get; set; }
        
        public string ContactName { get; set; }
        
        public string ContactPhone { get; set; }
        
        public string ContactEmail { get; set; }      
        
        public System.DateTime LastUpdated { get; set; }

        public ICollection<VehicleFeature> VehicleFeatures { get; set; }   
        
        public Vehicle()
        {
            this.VehicleFeatures = new List<VehicleFeature>();
        }
    }
}